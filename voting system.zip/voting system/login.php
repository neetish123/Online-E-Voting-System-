<?php
session_start();
include '../config.php';

//Create database
$user=$_POST['user'];
$pass=$_POST['pass'];
$conn = mysqli_connect($servername, $username, $password,$db);

	$sql="SELECT admin_user,admin_pass FROM admin WHERE admin_user='$user' and admin_pass='$pass'";
	$result=mysqli_query($conn,$sql);
	if (mysqli_num_rows($result)==1) {
    echo "you are logged in successfully! Welcome Admin";
    
    echo "<br><a href='addparty.php'>Click here for changes in voting</a>";
} else {
	echo "you are not registered<br>";
	echo "<br><a href='register_admin.html' target='_blank'>click here for registration</a><br>";
    echo "Error: '$sql' <br>".mysqli_error($conn);
}




mysqli_close($conn);
?>