<?php
function initiate()
{
	$server="127.0.0.1";
	$user="root";
	$pass="";
	$db="voting";
	$conn=mysqli_connect($server,$user,$pass,$db);
	if(!$conn)
	{
		echo "error:".mysqli_error($conn);
		return $pass;
	}
	else
	{
		return $conn;
	}
}

//function of making html for add_party

function sub1_html()
{
	echo "<br><br><br><br>";
	echo "<h1><u>Welcome Admin to Add New Party Pannel</u></h1><br>";
	echo "<table >";
echo "<form method='POST' action='addparty.php' enctype='multipart/form-data'>";
echo	"<tr><td>Please insert Logo here..&nbsp;&nbsp;";
		echo "<input type='file' name='pic' accept='image/* '>";
	echo "	</td>
		<td>Party Name:<input type='text' name='par' value='' size=70 placeholder='Party name here..'' title='please enter party name here'></td>";
		echo "<td><input type='submit' value='ADD_PARTY' name='sub11'></td>
	</tr>
</form>

</table>";

}

//function of deleting html for a party

function sub2_html()
{
	echo "<br><br><br><br>";
	echo "<h1><u>Welcome Admin to Delete an Existing Party Pannel</u></h1><br>";
	$con=initiate();
	$sql="SELECT party_Id,party_img,party_name FROM vote";
	$result=mysqli_query($con,$sql);
echo "
	<form method='POST' action='addparty.php' align='center'><table  align=center>";
if(mysqli_num_rows($result)>0)
{

	 while($row = mysqli_fetch_assoc($result)) {
echo "
		<tr>
			<td><input type='radio' name='party' value=".$row['party_Id']."></td>
			<td><b>".$row['party_name']."</b></td>";
			echo "<td><img src=uploads/".$row['party_img']." width=100px height=80px /></td>";
			echo "</tr>";
		}

		
}
else
{
	echo "no party exists..";
}
echo "</table>";
echo "<input type='submit' name='sub22' value='DELETE_THIS' align='center'>";
	echo "</form>";

}

function sub3_html()
{

}

function add_party($con,$sql)
{
if(mysqli_query($con,$sql))
{
    echo "<br><h3>New pary added Successfully";
    echo "<br><a href='home.html'>logOut</a>";
    echo "<a href='addparty.php'><h3>Click here to go for more changes</h3></a>";
}
else
{
	echo "<br>Party cannot be added <br>";
	echo "<br><a href='home.html'>logOut</a>";
	echo "<a href='addparty.php'><h3>Click here to go for more changes</h3></a>";
}

}
function del_party($sql,$name)
{
	$con=initiate();
	if(mysqli_query($con,$sql))
	{
		echo "<h2>Deleted party ID was:'$name' SuccessFully</h2><br>";
		echo "<a href='addparty.php'><h3>Click here to go for more changes</h3></a>";
	}
	else
	{
		echo "<br>Party is not Deleted<br>";
	}
	mysqli_close($con);
}

function Reset_votes()
{
	$con=initiate();
	$sqlv_up="UPDATE vote SET no_votes=0 WHERE 1";
	$sqlu_up="UPDATE user SET voted='no' WHERE 1";
if(mysqli_query($con,$sqlv_up))
{
	echo "<br><h2>Votes from Voting List are RESET SuccessFully</h2><br>";
	if(mysqli_query($con,$sqlu_up))
	{
		echo "<br><h2> User Votes from Voted List are RESET  SuccessFully</h2><br>";
	}
}
else
{
	echo "<br><h2>Votes RESET are UnSuccessful</h2><br>";
}


}


?>