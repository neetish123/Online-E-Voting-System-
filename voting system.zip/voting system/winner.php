<!DOCTYPE html>
<html>
<head>
	<title>Winner</title>
	 <link rel="icon" type="image/jpg" href="images/time.jpg"/>
	 <style type="text/css">
	 	body{
	 		background-image: url("images/giphy.gif");
	 		background-repeat: no-repeat;
	 		background-size: 1365px 670px;
	 	}
	 	h1
	 	{
	 		color: white;
	 		text-align: center;
	 	}
	 </style>
</head>
<body>
<h1><b><u>Congratulations You won The Election</u></b></h1><br>
<?php
include '../core.php';
$sql="SELECT party_Id,party_img,party_name FROM vote WHERE no_votes=(SELECT MAX(no_votes) FROM vote)";
$result=mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)) {
echo "<img src=uploads/".$row['party_img']." width=250px height=300px align='center' />";
echo "<h2 align='center' style='color:white;'>Party ID:".$row['party_Id'];
echo "<h2 align='center' style='color:white;'>Party name:".$row['party_name'];
}
mysqli_close($conn);
?>
</body>
</html>