<?php
include '../core.php';
if($_POST['pass']==$_POST['rpass'])
{
$cookie_name = $user=$_POST['user'];
$cookie_value =$_POST['pass']; 
$conn = mysqli_connect($servername, $username, $password,"voting");
if(isset($_POST['rem']))
{
	if(!isset($_COOKIE[$cookie_name])) {
    echo "<br>Cookie named '" . $cookie_name . "' is not set!<br>";
}else{
	
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
}
}

	$name=$_POST['f_name'];
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$mob=$_POST['mob'];
$sql = "INSERT INTO admin(admin_name,admin_user,admin_pass,admin_mobile) VALUES('$name', '$user', '$pass','$mob')";

if (mysqli_query($conn,$sql)) {
	echo "<h1>Congratulations Admin!</h1><br>";
    echo "New record created successfully";
    echo "<br>registered successfully<br>";
    echo "<br><a href='addparty.php'>Click here to check votes</a>";
    echo "&nbsp;&nbsp;&nbsp;<a href='home.html'> click here to go HOME</a>";

} else {
    echo "Error: '$sql' <br>".mysqli_error($conn);
    
}
}
else
{
	echo "password mismatch";
echo "<br><br><a href='register_admin.html'> Click here to register again</a>";
}
//signup($conn,$name,$user,$pass);


mysqli_close($conn);
?>