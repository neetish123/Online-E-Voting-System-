<?php
session_start();
include '../core.php';
$cal=0;
echo "<h1>Congratulations on your First vote</h1><br>";

	$val=$_POST['party'];
	$sql="SELECT no_votes from vote WHERE party_Id='$val'";
	$result=mysqli_query($conn,$sql);
	if (mysqli_num_rows($result) > 0)
{
	 while($row = mysqli_fetch_assoc($result)) {
	 $cal=$row['no_votes']+1;
}
}
$sq="UPDATE vote SET no_votes='$cal' WHERE party_Id='$val'";
if(mysqli_query($conn,$sq))
{
	echo "<h1>Thanks for Giving Vote!</h1><br>";
	echo "<a href='home.html'>Click here to goto home</a>";
}
$u=$_SESSION['u'];
$p=$_SESSION['p'];
$s="UPDATE user SET voted='yes' WHERE user='$u' and pass='$p'";
if(mysqli_query($conn,$s))
{
	echo "<h1>your vote is accepted</h1>";
}
mysqli_close($conn);
?>
