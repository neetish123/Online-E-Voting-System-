<?php
include '../core.php';
echo "<h1 align=center>Welcome to the users Voting Portal</h1><br>";
echo "<h2 align=center>Please select Radio button to vote then Submit</h2><br>";
$conn=mysqli_connect($servername,$username,$password,$db);
$sql="SELECT party_Id,party_img,party_name from vote";
$result=mysqli_query($conn,$sql);
echo "
	<form method='POST' action='votehome.php' align='center'><table border=1 align=center>";
if(mysqli_num_rows($result)>0)
{

	 while($row = mysqli_fetch_assoc($result)) {
echo "
		<tr>
			<td><input type='radio' name='party' value=".$row['party_Id']."></td>
			<td>".$row['party_name']."</td>";
			echo "<td><img src=uploads/".$row['party_img']." width=100px height=80px /></td>";
			echo "</tr>";
		}

		
}
else
{
	echo "no party exists..";
}
echo "</table>";
echo "<input type='submit' name='sub' value='vote' align='center'>";
	echo "</form>";
mysqli_close($conn);
?>