<?php
session_start();
include '../config.php';

//Create database
$user=$_POST['user'];
$pass=$_POST['pass'];
$_SESSION['u']=$user;
$_SESSION['p']=$pass;
$conn = mysqli_connect($servername, $username, $password,$db);

	$sql="SELECT user,pass,voted FROM user WHERE user='$user' and pass='$pass'";
	$result=mysqli_query($conn,$sql);
	if (mysqli_num_rows($result)==1 ){
    echo "you are logged in successfully";
     while($row = mysqli_fetch_assoc($result)) {
     	$c=$row['voted'];
     	if($c=="no"){
    echo "<br><a href='voterhome.php'>Click here to go for vote</a>";}
    else
    {
    	echo "<br><h1>You are already Voted</h1><br><a href='home.php'>Click here to go for home</a>";
    }
}
} else {
	echo "you are not registered<br>";
	echo "<br><a href='register.html' target='_blank'>click  here for registration</a><br>";
    echo "Error: '$sql' <br>".mysqli_error($conn);
}




mysqli_close($conn);
?>