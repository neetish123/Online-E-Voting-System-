<!DOCTYPE html>
<html>
<head>
	<title>Add new party</title>
    <link rel="icon" type="image/jpg" href="images/time.jpg"/>
</head>
<body>
	<h1>Admin's Personal Portal</h1>
<form method="POST" action="addparty.php">
<input type="submit" name="sub1" value="Add_New_party">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="sub2" value="Delete_party">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="sub3" value="Reset_votes">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="sub4" value="Play_Game">
</form>


<?php
include 'power_lib.php';

//Code to add a new party for voting on the basis of sub1 button

if(isset($_POST["sub1"]) OR isset($_POST['sub11']))
{
	if(!isset($_POST['sub11']))
	{
sub1_html();
}
else
{
$pnam=$_POST['par'];
$con=initiate();
$name=$_FILES["pic"]["name"];
move_uploaded_file($_FILES["pic"]["tmp_name"],"uploads/".$name);
$sql="INSERT INTO vote(party_img,party_name,no_votes) VALUES('$name','$pnam',0)";
add_party($con,$sql);
mysqli_close($con);
}
}

//Code to delete a party for voting on the basis of sub2 button


if(isset($_POST['sub2']) OR isset($_POST['sub22']))
{
	if(!isset($_POST['sub22']))
{
sub2_html();
}
else
{
$del=$_POST['party'];
$sql="DELETE FROM vote WHERE party_Id='$del'";
del_party($sql,$del);

}

}


// Code to reset party for voting

if(isset($_POST['sub3']))
{
Reset_votes();
}

if(isset($_POST['sub4']))
{
	echo "<br><u><h1>Welcome to the Gaming Pannel</h1></u><br>";
	echo "<iframe src='game.html' width=600px height=400px border=1></iframe>";
}
?>
</body>
</html>